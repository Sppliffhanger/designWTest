/* Copyright 1994-2002 The MathWorks, Inc.
 *
 * File    : cg_matrx.h       
 * Abstract:
 *	Provided for backwards compatibility. See rt_matrx.h for details.
 */

#include "rt_matrx.h"

/* [EOF] cg_matrx.h */
